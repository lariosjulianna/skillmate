//
//  SetupView.swift
//  skillmate_test
//
//  Created by Julianna on 3/14/24.
//

import SwiftUI

struct SetupView: View {
    var body: some View {
        Image("Image 1")
        .resizable()
        .aspectRatio(contentMode: .fit)
        
        Button("Continue") {
            /*@START_MENU_TOKEN@*//*@PLACEHOLDER=Action@*/ /*@END_MENU_TOKEN@*/
        }
    }
   
}


#Preview {
    SetupView()
}
