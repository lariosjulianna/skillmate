//
//  Setup2View.swift
//  skillmate_test
//
//  Created by Julianna on 3/14/24.
//

import SwiftUI

struct Setup2View: View {
    var body: some View {
        Image("Image")
        .resizable()
        .aspectRatio(contentMode: .fit)
    }
}

#Preview {
    Setup2View()
}
