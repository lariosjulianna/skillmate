//
//  FirstView.swift
//  skillmate_test
//
//  Created by Julianna on 3/14/24.


import SwiftUI

struct FirstView: View {
    var body: some View {
        Image("first")
        .resizable()
        .aspectRatio(contentMode: .fit)
        
        Button(/*@START_MENU_TOKEN@*/"Button"/*@END_MENU_TOKEN@*/) {
            /*@START_MENU_TOKEN@*//*@PLACEHOLDER=Action@*/ /*@END_MENU_TOKEN@*/
        }
    }
}

#Preview {
    FirstView()
}
