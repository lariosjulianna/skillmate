//
//  ContentView.swift
//  skillmate_test
//
//  Created by Julianna on 3/13/24.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        VStack {
            Image("skillmate_logo")
                .resizable()
                .aspectRatio(contentMode: .fit)
            
               // .imageScale(.large)
                //.foregroundStyle(.tint)
            Text("skillmate")
            Button("Sign Up") {
                /*@START_MENU_TOKEN@*//*@PLACEHOLDER=Action@*/ /*@END_MENU_TOKEN@*/
            }
        }
        .padding()
    }
}

#Preview {
    ContentView()
}
