//
//  Setup3View.swift
//  skillmate_test
//
//  Created by Julianna on 3/14/24.
//

import SwiftUI

struct Setup3View: View {
    var body: some View {
        Image("Setup4View")
        .resizable()
        .aspectRatio(contentMode: .fit)
    }
}

#Preview {
    Setup3View()
}
