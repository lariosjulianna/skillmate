//
//  skillmate_testApp.swift
//  skillmate_test
//
//  Created by Julianna on 3/13/24.
//

import SwiftUI

@main
struct skillmate_testApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
