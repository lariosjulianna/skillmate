//
//  SecondViewController.swift
//  proto_skillmate
//
//  Created by Julianna on 4/4/24.
//

import UIKit

class SecondViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = .systemPurple
        // Do any additional setup after loading the view.
    }


}
