//
//  ViewController.swift
//  proto_skillmate
//
//  Created by Julianna on 4/4/24.
//

import UIKit

class ViewController: UIViewController {

    private let button: UIButton = {
        let button = UIButton()
        button.backgroundColor = .systemBlue
        button.setTitle("Welcome to Skillmate", for: .normal)
        button.layer.cornerRadius = 7
        return button
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.setupUI()
        
        self.button.addTarget(self, action: #selector(didTapButton), for:
                .touchUpInside)
        
        // Do any additional setup after loading the view.
    }
    private func setupUI() {
        self.view.backgroundColor = .systemGreen
    
        
        self.view.addSubview(button)
        self.button.translatesAutoresizingMaskIntoConstraints = false
        
        NSLayoutConstraint.activate([
        button.centerXAnchor.constraint(equalTo: self.view.centerXAnchor),
        button.centerYAnchor.constraint(equalTo: self.view.centerYAnchor),
        button.widthAnchor.constraint(equalToConstant: 200),
        button.heightAnchor.constraint(equalToConstant: 44),
        ])
    }

    @objc func didTapButton() {
        print("Button pressed")
        let vc = SecondViewController()
        self.navigationController?.pushViewController(vc, animated: true)
        
        //self.present(vc, animated: true, //completion: nil)
    }
}
 // DISCLAIMER

/*
 I had so many issues with xcode! I couldn't finish the gui pages and had to restart, but I do have the code for screens and a button to go to the next screen! If you wanted to finish the GUI, We have a sample UI flowchart on the git, so just having the screens and buttons that lead to one another would be great
 */
